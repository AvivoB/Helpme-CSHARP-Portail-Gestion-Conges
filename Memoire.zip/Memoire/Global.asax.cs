﻿using System.Web;

namespace Memoire
{
    public class Global : HttpApplication
    {
        protected void Application_Start()
        {
        }
    }
}
